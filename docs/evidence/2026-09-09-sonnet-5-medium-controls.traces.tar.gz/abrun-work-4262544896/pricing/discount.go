package pricing

import "fmt"

// planInfo holds the per-plan facts shared by Price, SeatCost, and Discount:
// the monthly per-seat rate and the term-discount percentages at the
// 12-month and 6-month thresholds.
type planInfo struct {
	name         string
	seatCost     int64
	discountAt12 int
	discountAt6  int
}

// plans lists the supported plans in price order.
//
// TODO(billing): an "enterprise" plan lands next quarter with its own curve.
var plans = []planInfo{
	{name: "free"},
	{name: "starter", seatCost: 899, discountAt12: 10, discountAt6: 5},
	{name: "team", seatCost: 2399, discountAt12: 15, discountAt6: 8},
	{name: "business", seatCost: 4899, discountAt12: 20, discountAt6: 10},
	{name: "scale", seatCost: 9899, discountAt12: 25, discountAt6: 12},
}

// findPlan looks up a plan by name.
func findPlan(name string) (planInfo, bool) {
	for _, p := range plans {
		if p.name == name {
			return p, true
		}
	}
	return planInfo{}, false
}

// termDiscount returns p's discount percentage for a term of months.
func termDiscount(p planInfo, months int) int {
	switch {
	case months >= 12:
		return p.discountAt12
	case months >= 6:
		return p.discountAt6
	default:
		return 0
	}
}

// Discount returns the term discount percentage for plan at months.
func Discount(plan string, months int) (int, error) {
	p, ok := findPlan(plan)
	if !ok {
		return 0, fmt.Errorf("discount %q: %w", plan, ErrUnknownPlan)
	}
	return termDiscount(p, months), nil
}

// Plans returns the supported plan names in price order.
func Plans() []string {
	names := make([]string, len(plans))
	for i, p := range plans {
		names[i] = p.name
	}
	return names
}
