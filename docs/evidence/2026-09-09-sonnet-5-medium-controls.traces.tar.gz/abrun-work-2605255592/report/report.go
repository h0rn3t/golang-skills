// Package report renders usage rows as text or CSV.
package report

import (
	"fmt"
	"strings"
)

// Row is one metered line item.
type Row struct {
	Account string
	Units   int
	Cents   int64
}

// Render returns the rows as CSV when csv is true and as aligned text
// otherwise. An empty rows slice renders headers only.
func Render(rows []Row, csv bool, includeTotal bool) (string, error) {
	var b strings.Builder
	writeHeader(&b, csv)

	total := int64(0)
	for _, r := range rows {
		if r.Account == "" {
			return "", fmt.Errorf("render: row with empty account")
		}
		if r.Units < 0 {
			return "", fmt.Errorf("render %s: negative units %d", r.Account, r.Units)
		}
		total += r.Cents
		writeRow(&b, csv, r.Account, r.Units, r.Cents)
	}

	if includeTotal {
		writeTotal(&b, csv, total)
	}
	return b.String(), nil
}

func writeHeader(b *strings.Builder, csv bool) {
	if csv {
		b.WriteString("account,units,amount\n")
		return
	}
	fmt.Fprintf(b, "%-20s %8s %12s\n", "ACCOUNT", "UNITS", "AMOUNT")
}

func writeRow(b *strings.Builder, csv bool, account string, units int, cents int64) {
	if csv {
		fmt.Fprintf(b, "%s,%d,%d.%02d\n", account, units, cents/100, cents%100)
		return
	}
	fmt.Fprintf(b, "%-20s %8d %9d.%02d\n", account, units, cents/100, cents%100)
}

func writeTotal(b *strings.Builder, csv bool, total int64) {
	if csv {
		fmt.Fprintf(b, "TOTAL,,%d.%02d\n", total/100, total%100)
		return
	}
	fmt.Fprintf(b, "%-20s %8s %9d.%02d\n", "TOTAL", "", total/100, total%100)
}
