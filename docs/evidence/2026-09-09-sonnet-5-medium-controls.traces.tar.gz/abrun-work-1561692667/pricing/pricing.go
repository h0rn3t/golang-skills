// Package pricing computes subscription charges in cents.
package pricing

import (
	"errors"
	"fmt"
)

// ErrUnknownPlan reports a plan name the price list does not carry.
var ErrUnknownPlan = errors.New("unknown plan")

// planRate holds the per-seat monthly cost and term-discount curve for a plan.
type planRate struct {
	seatCost   int64
	discount12 int // discount percentage at 12+ months
	discount6  int // discount percentage at 6-11 months
}

var planRates = map[string]planRate{
	"free":     {seatCost: 0},
	"starter":  {seatCost: 899, discount12: 10, discount6: 5},
	"team":     {seatCost: 2399, discount12: 15, discount6: 8},
	"business": {seatCost: 4899, discount12: 20, discount6: 10},
	"scale":    {seatCost: 9899, discount12: 25, discount6: 12},
}

// discountPct returns rate's term discount percentage at months.
func discountPct(rate planRate, months int) int {
	switch {
	case months >= 12:
		return rate.discount12
	case months >= 6:
		return rate.discount6
	default:
		return 0
	}
}

// Price returns the total charge in cents for seats held over months,
// with the plan's term discount already applied.
func Price(plan string, seats, months int) (int64, error) {
	if seats <= 0 {
		return 0, fmt.Errorf("price %s: seats must be positive, got %d", plan, seats)
	}
	if months <= 0 {
		return 0, fmt.Errorf("price %s: months must be positive, got %d", plan, months)
	}
	rate, ok := planRates[plan]
	if !ok {
		return 0, fmt.Errorf("price %q: %w", plan, ErrUnknownPlan)
	}
	total := rate.seatCost * int64(seats) * int64(months)
	pct := discountPct(rate, months)
	total -= total * int64(pct) / 100
	return total, nil
}

// SeatCost returns the undiscounted per-seat monthly rate in cents.
func SeatCost(plan string) (int64, error) {
	rate, ok := planRates[plan]
	if !ok {
		return 0, fmt.Errorf("seat cost %q: %w", plan, ErrUnknownPlan)
	}
	return rate.seatCost, nil
}
