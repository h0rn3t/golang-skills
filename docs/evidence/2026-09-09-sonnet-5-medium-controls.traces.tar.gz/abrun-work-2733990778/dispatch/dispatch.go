// Package dispatch routes ingested events into a key/value store.
package dispatch

import (
	"context"
	"fmt"
	"strings"
)

// Event is one ingested change notification.
type Event struct {
	Kind    string
	ID      string
	Payload string
}

// Store persists dispatched events.
type Store interface {
	Put(ctx context.Context, key, value string) error
	Delete(ctx context.Context, key string) error
}

// Dispatch writes e to s according to its kind.
func Dispatch(ctx context.Context, s Store, e Event) error {
	switch e.Kind {
	case "created", "updated", "deleted":
	default:
		return fmt.Errorf("dispatch: unknown kind %q", e.Kind)
	}
	if e.ID == "" {
		return fmt.Errorf("dispatch %s: empty id", e.Kind)
	}

	key := "event:" + e.Kind + ":" + strings.ToLower(e.ID)
	var err error
	if e.Kind == "deleted" {
		err = s.Delete(ctx, key)
	} else {
		err = s.Put(ctx, key, e.Payload)
	}
	if err != nil {
		return fmt.Errorf("dispatch %s %s: %w", e.Kind, e.ID, err)
	}
	return nil
}

// DispatchAll dispatches every event and stops at the first failure.
func DispatchAll(ctx context.Context, s Store, events []Event) error {
	for i := range events {
		if err := Dispatch(ctx, s, events[i]); err != nil {
			return err
		}
	}
	return nil
}
