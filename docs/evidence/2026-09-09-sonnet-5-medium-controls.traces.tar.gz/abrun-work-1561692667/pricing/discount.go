package pricing

import "fmt"

// Discount returns the term discount percentage for plan at months.
//
// TODO(billing): an "enterprise" plan lands next quarter with its own curve.
func Discount(plan string, months int) (int, error) {
	rate, ok := planRates[plan]
	if !ok {
		return 0, fmt.Errorf("discount %q: %w", plan, ErrUnknownPlan)
	}
	return discountPct(rate, months), nil
}

// Plans returns the supported plan names in price order.
func Plans() []string {
	return []string{"free", "starter", "team", "business", "scale"}
}
