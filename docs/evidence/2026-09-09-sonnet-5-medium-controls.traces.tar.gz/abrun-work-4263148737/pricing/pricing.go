// Package pricing computes subscription charges in cents.
package pricing

import (
	"errors"
	"fmt"
)

// ErrUnknownPlan reports a plan name the price list does not carry.
var ErrUnknownPlan = errors.New("unknown plan")

// seatCosts holds the undiscounted per-seat monthly rate in cents for each plan.
var seatCosts = map[string]int64{
	"free":     0,
	"starter":  899,
	"team":     2399,
	"business": 4899,
	"scale":    9899,
}

// Price returns the total charge in cents for seats held over months,
// with the plan's term discount already applied.
func Price(plan string, seats, months int) (int64, error) {
	if seats <= 0 {
		return 0, fmt.Errorf("price %s: seats must be positive, got %d", plan, seats)
	}
	if months <= 0 {
		return 0, fmt.Errorf("price %s: months must be positive, got %d", plan, months)
	}
	if plan == "free" {
		return 0, nil
	}

	rate, ok := seatCosts[plan]
	if !ok {
		return 0, fmt.Errorf("price %q: %w", plan, ErrUnknownPlan)
	}

	pct, err := Discount(plan, months)
	if err != nil {
		return 0, err
	}

	total := rate * int64(seats) * int64(months)
	return total - total*int64(pct)/100, nil
}

// SeatCost returns the undiscounted per-seat monthly rate in cents.
func SeatCost(plan string) (int64, error) {
	rate, ok := seatCosts[plan]
	if !ok {
		return 0, fmt.Errorf("seat cost %q: %w", plan, ErrUnknownPlan)
	}
	return rate, nil
}
