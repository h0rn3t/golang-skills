module abeval

go 1.27
