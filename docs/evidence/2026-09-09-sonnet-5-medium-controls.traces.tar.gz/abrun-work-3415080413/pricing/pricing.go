// Package pricing computes subscription charges in cents.
package pricing

import (
	"errors"
	"fmt"
)

// ErrUnknownPlan reports a plan name the price list does not carry.
var ErrUnknownPlan = errors.New("unknown plan")

// discountTier grants pct off once a subscription runs for at least months.
// Tiers must be sorted by months descending.
type discountTier struct {
	months int
	pct    int
}

// planInfo holds the pricing data for a single plan.
type planInfo struct {
	seatCost int64
	tiers    []discountTier
}

// planOrder lists the supported plan names in price order.
var planOrder = []string{"free", "starter", "team", "business", "scale"}

var plans = map[string]planInfo{
	"free":     {seatCost: 0},
	"starter":  {seatCost: 899, tiers: []discountTier{{12, 10}, {6, 5}}},
	"team":     {seatCost: 2399, tiers: []discountTier{{12, 15}, {6, 8}}},
	"business": {seatCost: 4899, tiers: []discountTier{{12, 20}, {6, 10}}},
	"scale":    {seatCost: 9899, tiers: []discountTier{{12, 25}, {6, 12}}},
}

// Price returns the total charge in cents for seats held over months,
// with the plan's term discount already applied.
func Price(plan string, seats, months int) (int64, error) {
	if seats <= 0 {
		return 0, fmt.Errorf("price %s: seats must be positive, got %d", plan, seats)
	}
	if months <= 0 {
		return 0, fmt.Errorf("price %s: months must be positive, got %d", plan, months)
	}
	info, ok := plans[plan]
	if !ok {
		return 0, fmt.Errorf("price %q: %w", plan, ErrUnknownPlan)
	}
	if plan == "free" {
		return 0, nil
	}
	total := info.seatCost * int64(seats) * int64(months)
	pct, err := Discount(plan, months)
	if err != nil {
		return 0, err
	}
	total -= total * int64(pct) / 100
	return total, nil
}

// SeatCost returns the undiscounted per-seat monthly rate in cents.
func SeatCost(plan string) (int64, error) {
	info, ok := plans[plan]
	if !ok {
		return 0, fmt.Errorf("seat cost %q: %w", plan, ErrUnknownPlan)
	}
	return info.seatCost, nil
}
