// Package report renders usage rows as text or CSV.
package report

import (
	"fmt"
	"strings"
)

// Row is one metered line item.
type Row struct {
	Account string
	Units   int
	Cents   int64
}

// Render returns the rows as CSV when csv is true and as aligned text
// otherwise. An empty rows slice renders headers only.
func Render(rows []Row, csv bool, includeTotal bool) (string, error) {
	var b strings.Builder
	if csv {
		b.WriteString("account,units,amount\n")
	} else {
		b.WriteString(fmt.Sprintf("%-20s %8s %12s\n", "ACCOUNT", "UNITS", "AMOUNT"))
	}

	total := int64(0)
	for _, r := range rows {
		if r.Account == "" {
			return "", fmt.Errorf("render: row with empty account")
		}
		if r.Units < 0 {
			return "", fmt.Errorf("render %s: negative units %d", r.Account, r.Units)
		}
		total += r.Cents
		if csv {
			b.WriteString(fmt.Sprintf("%s,%d,%s\n", r.Account, r.Units, formatCents(r.Cents)))
		} else {
			b.WriteString(fmt.Sprintf("%-20s %8d %12s\n", r.Account, r.Units, formatCents(r.Cents)))
		}
	}

	if includeTotal {
		if csv {
			b.WriteString(fmt.Sprintf("TOTAL,,%s\n", formatCents(total)))
		} else {
			b.WriteString(fmt.Sprintf("%-20s %8s %12s\n", "TOTAL", "", formatCents(total)))
		}
	}
	return b.String(), nil
}

// formatCents renders a cents amount as a "dollars.cents" string.
func formatCents(cents int64) string {
	return fmt.Sprintf("%d.%02d", cents/100, cents%100)
}
