// Package report renders usage rows as text or CSV.
package report

import (
	"fmt"
	"strings"
)

// Row is one metered line item.
type Row struct {
	Account string
	Units   int
	Cents   int64
}

// Render returns the rows as CSV when csv is true and as aligned text
// otherwise. An empty rows slice renders headers only.
func Render(rows []Row, csv bool, includeTotal bool) (string, error) {
	var b strings.Builder
	writeHeader(&b, csv)

	total := int64(0)
	for _, r := range rows {
		if err := validateRow(r); err != nil {
			return "", err
		}
		total += r.Cents
		writeRow(&b, csv, r)
	}

	if includeTotal {
		writeTotal(&b, csv, total)
	}
	return b.String(), nil
}

func validateRow(r Row) error {
	if r.Account == "" {
		return fmt.Errorf("render: row with empty account")
	}
	if r.Units < 0 {
		return fmt.Errorf("render %s: negative units %d", r.Account, r.Units)
	}
	return nil
}

func writeHeader(b *strings.Builder, csv bool) {
	if csv {
		b.WriteString("account,units,amount\n")
	} else {
		fmt.Fprintf(b, "%-20s %8s %12s\n", "ACCOUNT", "UNITS", "AMOUNT")
	}
}

func writeRow(b *strings.Builder, csv bool, r Row) {
	dollars, cents := r.Cents/100, r.Cents%100
	if csv {
		fmt.Fprintf(b, "%s,%d,%d.%02d\n", r.Account, r.Units, dollars, cents)
	} else {
		fmt.Fprintf(b, "%-20s %8d %9d.%02d\n", r.Account, r.Units, dollars, cents)
	}
}

func writeTotal(b *strings.Builder, csv bool, total int64) {
	dollars, cents := total/100, total%100
	if csv {
		fmt.Fprintf(b, "TOTAL,,%d.%02d\n", dollars, cents)
	} else {
		fmt.Fprintf(b, "%-20s %8s %9d.%02d\n", "TOTAL", "", dollars, cents)
	}
}
