package pricing

import "fmt"

// discountTier grants pct off once a subscription runs for at least months.
type discountTier struct {
	months int
	pct    int
}

// discountTiers lists each plan's term discounts, longest term first.
//
// TODO(billing): an "enterprise" plan lands next quarter with its own curve.
var discountTiers = map[string][]discountTier{
	"free":     {},
	"starter":  {{12, 10}, {6, 5}},
	"team":     {{12, 15}, {6, 8}},
	"business": {{12, 20}, {6, 10}},
	"scale":    {{12, 25}, {6, 12}},
}

// Discount returns the term discount percentage for plan at months.
func Discount(plan string, months int) (int, error) {
	tiers, ok := discountTiers[plan]
	if !ok {
		return 0, fmt.Errorf("discount %q: %w", plan, ErrUnknownPlan)
	}
	for _, tier := range tiers {
		if months >= tier.months {
			return tier.pct, nil
		}
	}
	return 0, nil
}

// Plans returns the supported plan names in price order.
func Plans() []string {
	return []string{"free", "starter", "team", "business", "scale"}
}
