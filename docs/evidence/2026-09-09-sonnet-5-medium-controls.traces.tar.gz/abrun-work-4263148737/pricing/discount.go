package pricing

import "fmt"

// tier is a term-length threshold and the discount percentage it unlocks.
type tier struct {
	months  int
	percent int
}

// discountTiers holds each plan's term discount curve, ordered from
// longest term to shortest.
//
// TODO(billing): an "enterprise" plan lands next quarter with its own curve.
var discountTiers = map[string][]tier{
	"free":     {},
	"starter":  {{12, 10}, {6, 5}},
	"team":     {{12, 15}, {6, 8}},
	"business": {{12, 20}, {6, 10}},
	"scale":    {{12, 25}, {6, 12}},
}

// Discount returns the term discount percentage for plan at months.
func Discount(plan string, months int) (int, error) {
	tiers, ok := discountTiers[plan]
	if !ok {
		return 0, fmt.Errorf("discount %q: %w", plan, ErrUnknownPlan)
	}
	for _, t := range tiers {
		if months >= t.months {
			return t.percent, nil
		}
	}
	return 0, nil
}

// Plans returns the supported plan names in price order.
func Plans() []string {
	return []string{"free", "starter", "team", "business", "scale"}
}
