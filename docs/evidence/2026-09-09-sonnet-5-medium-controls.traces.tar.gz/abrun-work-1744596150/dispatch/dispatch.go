// Package dispatch routes ingested events into a key/value store.
package dispatch

import (
	"context"
	"fmt"
	"strings"
)

// Event is one ingested change notification.
type Event struct {
	Kind    string
	ID      string
	Payload string
}

// Store persists dispatched events.
type Store interface {
	Put(ctx context.Context, key, value string) error
	Delete(ctx context.Context, key string) error
}

// Dispatch writes e to s according to its kind.
func Dispatch(ctx context.Context, s Store, e Event) error {
	switch e.Kind {
	case "created":
		return put(ctx, s, e, "created")
	case "updated":
		return put(ctx, s, e, "updated")
	case "deleted":
		if e.ID == "" {
			return fmt.Errorf("dispatch deleted: empty id")
		}
		if err := s.Delete(ctx, eventKey("deleted", e.ID)); err != nil {
			return fmt.Errorf("dispatch deleted %s: %w", e.ID, err)
		}
		return nil
	default:
		return fmt.Errorf("dispatch: unknown kind %q", e.Kind)
	}
}

// put stores e's payload under a key derived from kind, used for the
// "created" and "updated" kinds which share identical handling.
func put(ctx context.Context, s Store, e Event, kind string) error {
	if e.ID == "" {
		return fmt.Errorf("dispatch %s: empty id", kind)
	}
	if err := s.Put(ctx, eventKey(kind, e.ID), e.Payload); err != nil {
		return fmt.Errorf("dispatch %s %s: %w", kind, e.ID, err)
	}
	return nil
}

func eventKey(kind, id string) string {
	return "event:" + kind + ":" + strings.ToLower(id)
}

// DispatchAll dispatches every event and stops at the first failure.
func DispatchAll(ctx context.Context, s Store, events []Event) error {
	for _, e := range events {
		if err := Dispatch(ctx, s, e); err != nil {
			return err
		}
	}
	return nil
}
