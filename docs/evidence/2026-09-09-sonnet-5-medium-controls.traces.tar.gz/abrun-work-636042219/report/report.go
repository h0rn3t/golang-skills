// Package report renders usage rows as text or CSV.
package report

import (
	"fmt"
	"strings"
)

// Row is one metered line item.
type Row struct {
	Account string
	Units   int
	Cents   int64
}

// Render returns the rows as CSV when csv is true and as aligned text
// otherwise. An empty rows slice renders headers only.
func Render(rows []Row, csv bool, includeTotal bool) (string, error) {
	var b strings.Builder
	writeHeader(&b, csv)

	total := int64(0)
	for _, r := range rows {
		if r.Account == "" {
			return "", fmt.Errorf("render: row with empty account")
		}
		if r.Units < 0 {
			return "", fmt.Errorf("render %s: negative units %d", r.Account, r.Units)
		}
		total += r.Cents
		writeRow(&b, csv, r.Account, fmt.Sprintf("%d", r.Units), r.Cents)
	}

	if includeTotal {
		writeRow(&b, csv, "TOTAL", "", total)
	}
	return b.String(), nil
}

func writeHeader(b *strings.Builder, csv bool) {
	if csv {
		b.WriteString("account,units,amount\n")
	} else {
		fmt.Fprintf(b, "%-20s %8s %12s\n", "ACCOUNT", "UNITS", "AMOUNT")
	}
}

// writeRow renders a data or total row. units is pre-formatted so the total
// row can pass an empty string.
func writeRow(b *strings.Builder, csv bool, account, units string, cents int64) {
	dollars, remainder := cents/100, cents%100
	if csv {
		fmt.Fprintf(b, "%s,%s,%d.%02d\n", account, units, dollars, remainder)
	} else {
		fmt.Fprintf(b, "%-20s %8s %9d.%02d\n", account, units, dollars, remainder)
	}
}
