// Package dispatch routes ingested events into a key/value store.
package dispatch

import (
	"context"
	"fmt"
	"strings"
)

// Event is one ingested change notification.
type Event struct {
	Kind    string
	ID      string
	Payload string
}

// Store persists dispatched events.
type Store interface {
	Put(ctx context.Context, key, value string) error
	Delete(ctx context.Context, key string) error
}

// keyPrefixes maps each recognized event kind to the key prefix used to
// store it and whether dispatching it deletes rather than puts.
var keyPrefixes = map[string]struct {
	prefix string
	delete bool
}{
	"created": {prefix: "event:created:"},
	"updated": {prefix: "event:updated:"},
	"deleted": {prefix: "event:deleted:", delete: true},
}

// Dispatch writes e to s according to its kind.
func Dispatch(ctx context.Context, s Store, e Event) error {
	op, ok := keyPrefixes[e.Kind]
	if !ok {
		return fmt.Errorf("dispatch: unknown kind %q", e.Kind)
	}
	if e.ID == "" {
		return fmt.Errorf("dispatch %s: empty id", e.Kind)
	}
	key := op.prefix + strings.ToLower(e.ID)
	var err error
	if op.delete {
		err = s.Delete(ctx, key)
	} else {
		err = s.Put(ctx, key, e.Payload)
	}
	if err != nil {
		return fmt.Errorf("dispatch %s %s: %w", e.Kind, e.ID, err)
	}
	return nil
}

// DispatchAll dispatches every event and stops at the first failure.
func DispatchAll(ctx context.Context, s Store, events []Event) error {
	for _, e := range events {
		if err := Dispatch(ctx, s, e); err != nil {
			return err
		}
	}
	return nil
}
