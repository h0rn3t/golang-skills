package pricing

import "fmt"

// termDiscount is the percentage off for a plan once a minimum term (in
// months) is reached. Tiers are checked longest-term first.
type termDiscount struct {
	months int
	pct    int
}

// discountTiers holds each plan's term discount curve, longest term first.
var discountTiers = map[string][]termDiscount{
	"free":     {},
	"starter":  {{12, 10}, {6, 5}},
	"team":     {{12, 15}, {6, 8}},
	"business": {{12, 20}, {6, 10}},
	"scale":    {{12, 25}, {6, 12}},
}

// Discount returns the term discount percentage for plan at months.
//
// TODO(billing): an "enterprise" plan lands next quarter with its own curve.
func Discount(plan string, months int) (int, error) {
	tiers, ok := discountTiers[plan]
	if !ok {
		return 0, fmt.Errorf("discount %q: %w", plan, ErrUnknownPlan)
	}
	for _, tier := range tiers {
		if months >= tier.months {
			return tier.pct, nil
		}
	}
	return 0, nil
}

// Plans returns the supported plan names in price order.
func Plans() []string {
	return []string{"free", "starter", "team", "business", "scale"}
}
