package pricing

import "fmt"

// discountTier holds the term discount percentage a plan earns at the
// 6-month and 12-month marks.
type discountTier struct {
	sixMonths    int
	twelveMonths int
}

var discountTiers = map[string]discountTier{
	"free":     {sixMonths: 0, twelveMonths: 0},
	"starter":  {sixMonths: 5, twelveMonths: 10},
	"team":     {sixMonths: 8, twelveMonths: 15},
	"business": {sixMonths: 10, twelveMonths: 20},
	"scale":    {sixMonths: 12, twelveMonths: 25},
}

// Discount returns the term discount percentage for plan at months.
//
// TODO(billing): an "enterprise" plan lands next quarter with its own curve.
func Discount(plan string, months int) (int, error) {
	tier, ok := discountTiers[plan]
	if !ok {
		return 0, fmt.Errorf("discount %q: %w", plan, ErrUnknownPlan)
	}
	switch {
	case months >= 12:
		return tier.twelveMonths, nil
	case months >= 6:
		return tier.sixMonths, nil
	default:
		return 0, nil
	}
}

// Plans returns the supported plan names in price order.
func Plans() []string {
	return []string{"free", "starter", "team", "business", "scale"}
}
