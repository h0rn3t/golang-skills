// Package report renders usage rows as text or CSV.
package report

import (
	"fmt"
	"strings"
)

// Row is one metered line item.
type Row struct {
	Account string
	Units   int
	Cents   int64
}

// Render returns the rows as CSV when csv is true and as aligned text
// otherwise. An empty rows slice renders headers only.
func Render(rows []Row, csv bool, includeTotal bool) (string, error) {
	var b strings.Builder
	if csv {
		b.WriteString("account,units,amount\n")
	} else {
		b.WriteString(fmt.Sprintf("%-20s %8s %12s\n", "ACCOUNT", "UNITS", "AMOUNT"))
	}

	var total int64
	for _, r := range rows {
		if r.Account == "" {
			return "", fmt.Errorf("render: row with empty account")
		}
		if r.Units < 0 {
			return "", fmt.Errorf("render %s: negative units %d", r.Account, r.Units)
		}
		total += r.Cents
		whole, frac := dollars(r.Cents)
		if csv {
			b.WriteString(fmt.Sprintf("%s,%d,%d.%02d\n", r.Account, r.Units, whole, frac))
		} else {
			b.WriteString(fmt.Sprintf("%-20s %8d %9d.%02d\n", r.Account, r.Units, whole, frac))
		}
	}

	if includeTotal {
		whole, frac := dollars(total)
		if csv {
			b.WriteString(fmt.Sprintf("TOTAL,,%d.%02d\n", whole, frac))
		} else {
			b.WriteString(fmt.Sprintf("%-20s %8s %9d.%02d\n", "TOTAL", "", whole, frac))
		}
	}
	return b.String(), nil
}

// dollars splits cents into whole-dollar and two-digit-cent components.
func dollars(cents int64) (whole, frac int64) {
	return cents / 100, cents % 100
}
