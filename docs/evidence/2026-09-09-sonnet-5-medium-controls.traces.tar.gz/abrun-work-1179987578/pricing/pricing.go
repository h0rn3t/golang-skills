// Package pricing computes subscription charges in cents.
package pricing

import (
	"errors"
	"fmt"
)

// ErrUnknownPlan reports a plan name the price list does not carry.
var ErrUnknownPlan = errors.New("unknown plan")

// discountTier applies percent off once a term reaches minMonths. Tiers for
// a plan are ordered from longest to shortest term.
type discountTier struct {
	minMonths int
	percent   int
}

// planSpec holds the per-plan facts a price or discount lookup depends on.
type planSpec struct {
	seatCost int64
	tiers    []discountTier
}

var planSpecs = map[string]planSpec{
	"free":     {},
	"starter":  {seatCost: 899, tiers: []discountTier{{12, 10}, {6, 5}}},
	"team":     {seatCost: 2399, tiers: []discountTier{{12, 15}, {6, 8}}},
	"business": {seatCost: 4899, tiers: []discountTier{{12, 20}, {6, 10}}},
	"scale":    {seatCost: 9899, tiers: []discountTier{{12, 25}, {6, 12}}},
}

// discountPercent returns the percentage for the tier the term qualifies for,
// or 0 if the term is too short for any tier.
func discountPercent(tiers []discountTier, months int) int {
	for _, t := range tiers {
		if months >= t.minMonths {
			return t.percent
		}
	}
	return 0
}

// Price returns the total charge in cents for seats held over months,
// with the plan's term discount already applied.
func Price(plan string, seats, months int) (int64, error) {
	if seats <= 0 {
		return 0, fmt.Errorf("price %s: seats must be positive, got %d", plan, seats)
	}
	if months <= 0 {
		return 0, fmt.Errorf("price %s: months must be positive, got %d", plan, months)
	}
	spec, ok := planSpecs[plan]
	if !ok {
		return 0, fmt.Errorf("price %q: %w", plan, ErrUnknownPlan)
	}
	total := spec.seatCost * int64(seats) * int64(months)
	pct := discountPercent(spec.tiers, months)
	total -= total * int64(pct) / 100
	return total, nil
}

// SeatCost returns the undiscounted per-seat monthly rate in cents.
func SeatCost(plan string) (int64, error) {
	spec, ok := planSpecs[plan]
	if !ok {
		return 0, fmt.Errorf("seat cost %q: %w", plan, ErrUnknownPlan)
	}
	return spec.seatCost, nil
}
